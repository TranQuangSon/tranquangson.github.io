function sum(a, b) {
    console.log(a + b);
}
sum(10, 20)