// let username: string;
// username = "datlt"
// console.log(username);
// const phoneNumber: number = 1234566;
// const arrNumber: number[] = [1, 2, 3];
// const arrStr: string[] = ["1234", "def"];
// const arrMix: Array<number | string | boolean> = [1, "abcd", true];
// const isAdmin: boolean = true;
// const project: { id: number, name: string, email?: string } = {
//     id: 1,
//     name: "project 1",
//     email: "abcd@gmail.com"
// }
// function sum(a: number, b: number): any {
//     let result = a + b
//     return result
// }
// sum(10, 20)
var arrNumber = [1, 2, 3];
var arrMix = [
    { id: 1, name: "abc" }
];
var projectList = [
    { id: 1, name: "abc", image: "ac", link: "abc", status: "true" },
    { id: 1, name: "abc", image: "ac", link: "abc" }
];
var sum = function (a, b) {
    return 123;
};
sum(10, 20);
var add = function (a) {
    return a;
};
add(projectList);
var sontv = {
    id: 999999,
    name: "sontv",
    email: "sontv@gmail.com"
};
